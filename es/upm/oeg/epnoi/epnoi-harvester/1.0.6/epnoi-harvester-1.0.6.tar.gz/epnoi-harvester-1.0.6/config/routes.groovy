import es.upm.oeg.epnoi.harvester.BaseRouteBuilder
import org.apache.camel.LoggingLevel
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import static es.upm.oeg.epnoi.harvester.HarvesterRouteBuilder.*

class routes extends BaseRouteBuilder {

    protected static final Logger LOG = LoggerFactory.getLogger(routes.class);

    @Override
    public void configure() throws Exception {

//        /*********************************************************************************************************************************
//         * ROUTE 1: RSS
//         *********************************************************************************************************************************/
//        from("file:"+inputDir+"/rss?recursive=true&include=.*\\.xml&doneFileName=\${file:name}.done").
//                to("direct:setCommonRssXpathExpressions").
//                to("seda:createRO")
//
//
//        /*********************************************************************************************************************************
//         * ROUTE 2: OAIPMH
//         *********************************************************************************************************************************/
//        from("file:"+inputDir+"/oaipmh?recursive=true&include=.*\\.xml&doneFileName=\${file:name}.done").
//                to("direct:setCommonOaipmhXpathExpressions").
//                to("seda:createRO")


//        /*********************************************************************************************************************************
//         * ROUTE 3: SIGGRAPH-PDF
//         *********************************************************************************************************************************/
//        from("file:"+inputDir+"/papers?recursive=true&include=.*\\.pdf").
//                setProperty(SOURCE_PROTOCOL,            constant("pdf")).
//                setProperty(SOURCE_URI,                 simple("http://www.epnoi.org/pdf/\${property." + SOURCE_NAME + "}")).
//                setProperty(SOURCE_NAME,                constant("acm-siggraph-2006-2014")).
//                setProperty(SOURCE_URL,                 simple("\${header.CamelFileParent}")).
//                setProperty(PUBLICATION_TITLE,          simple("\${header.CamelFileNameOnly}")).
//                setProperty(PUBLICATION_DESCRIPTION,    simple("\${header.CamelFileAbsolutePath}")).
//                setProperty(PUBLICATION_PUBLISHED,      simple("\${header.CamelFileParent}")).
//                setProperty(PUBLICATION_URI,            simple("\${header.CamelFileAbsolutePath}")).
//                setProperty(PUBLICATION_URL,            simple("\${header.CamelFileAbsolutePath}")).
//                setProperty(PUBLICATION_URL_LOCAL,      simple("\${header.CamelFileAbsolutePath}")).
//                setProperty(PUBLICATION_LANGUAGE,       constant("en")).
//                setProperty(PUBLICATION_RIGHTS,         constant("ACM Publishing License Agreement")).
//                setProperty(PUBLICATION_CREATORS,       constant("Shaopeng, Wu")).
//                setProperty(PUBLICATION_FORMAT,         constant("pdf")).
//                setProperty(PUBLICATION_METADATA_FORMAT,constant("xml")).
//                setProperty(PUBLICATION_METADATA_FORMAT,constant("xml")).
//                setProperty(PUBLICATION_REFERENCE_URL,  simple("\${header.CamelFileAbsolutePath}")).
//                to("seda:createRO")

        /*********************************************************************************************************************************
         * ROUTE 4: ISWC-PDF
         *********************************************************************************************************************************/
        from("file:"+inputDir+"?recursive=true&include=.*\\.pdf").
                setProperty(SOURCE_PROTOCOL,            constant("pdf")).
                setProperty(SOURCE_URI,                 constant("http://www.epnoi.org/pdf/iswc-2015")).
                setProperty(SOURCE_NAME,                constant("iswc-2015")).
                setProperty(SOURCE_URL,                 simple("http://www.cse.lehigh.edu/~heflin/iswc2015-usb/Papers/\${header.CamelFileNameOnly}")).
                setProperty(PUBLICATION_TITLE,          simple("\${header.CamelFileNameOnly}")).
                setProperty(PUBLICATION_DESCRIPTION,    simple("\${header.CamelFileAbsolutePath}")).
                setProperty(PUBLICATION_PUBLISHED,      simple("\${header.CamelFileParent}")).
                setProperty(PUBLICATION_URI,            simple("\${header.CamelFileAbsolutePath}")).
                setProperty(PUBLICATION_URL,            simple("\${header.CamelFileAbsolutePath}")).
                setProperty(PUBLICATION_URL_LOCAL,      simple("\${header.CamelFileAbsolutePath}")).
                setProperty(PUBLICATION_LANGUAGE,       constant("en")).
                setProperty(PUBLICATION_RIGHTS,         constant("ISWC Publishing License Agreement")).
                setProperty(PUBLICATION_CREATORS,       constant("Bethlehem, Pennsylvania")).
                setProperty(PUBLICATION_FORMAT,         constant("pdf")).
                setProperty(PUBLICATION_METADATA_FORMAT,constant("xml")).
                setProperty(PUBLICATION_METADATA_FORMAT,constant("xml")).
                setProperty(PUBLICATION_REFERENCE_URL,  simple("\${header.CamelFileAbsolutePath}")).
                to("seda:createRO")


        /*********************************************************************************************************************************
         * -> To UIA
         *********************************************************************************************************************************/
        from("seda:createRO").
                process(roBuilder).
                log(LoggingLevel.INFO,LOG,"File Read: '\${header.CamelFileName}'").
                to("file:"+outputDir+"?fileName=\${header.FileName}")

    }

}
